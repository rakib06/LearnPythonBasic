import random

f = open("data2.txt","r")

myList = []

for line in f:
	line.split(" ")
	value2 = ""
	for value in line:
		if value != " ":
			value2 += value		
		else:
			if value2 != "":
				value2 = int(value2)
				myList.append(value2)
			value2 = ""
print(myList)

departments = myList[0]
time_period = myList [1]
print (departments)
print (time_period)
print(len(myList))

# time period X = matrix X 
# shifing cost = shiftCost[] 
shiftCost = []

flowCost = []
flowCost2 =[]
dep = 1;
time =1;
for i in range(3,len(myList)):
	
	

	if i >= len(myList) - departments :
		shiftCost.append(myList[i])
	else:

		if (len(flowCost) >= 6):
			#print (len(flowCost)   % departments )
			flowCost2.append(flowCost)
			flowCost =[]
			flowCost.append(myList[i])
		else:
			flowCost.append(myList[i])
			
print(shiftCost)
flowCost2.append(flowCost)
print (flowCost2)
#print (flowCost2[0])



t_f_1= []
for k in range (0, departments):
	
	for l in range (0, departments):
		t_f_1.append(flowCost2[k][l])
	
#t_f_1.append(flowCost2[k][l])
print("t_f:\n")
print(t_f_1)
def SequenceGenerator(period, department):

    numbers = []
    for j in range (0,period):
    	num = []
    	for i in range(1,department + 1):
        	num.append(i)
    	random.shuffle(num)
    	numbers.append(num)
    return numbers
    
sg = SequenceGenerator(time_period,departments)

print (sg)

def CalculateEnergy( sequence , flowcost, shifting_cost):
	print(sequence)

CalculateEnergy (sg[1], 1,2)